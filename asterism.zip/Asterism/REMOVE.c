#include <stdio.h>
#include <stdlib.h>

// Remove Asterism

int main()
{
system("./REMOVE.sh");
}
