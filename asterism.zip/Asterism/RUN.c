#include <stdio.h>
#include <stdlib.h>

// Run Asterism

int main()
{
system("./asterism");
}
