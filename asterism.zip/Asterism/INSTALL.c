#include <stdio.h>
#include <stdlib.h>

// Install Asterism

int main()
{
system("./INSTALL.sh");
}
